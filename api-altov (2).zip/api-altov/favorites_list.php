<?php
require_once "db.php";
header("Content-Type: application/json");

$user_id = intval($_GET["user_id"] ?? 0);
if ($user_id <= 0) { echo json_encode([]); exit; }

$sql = "SELECT c.* 
        FROM favorites f 
        JOIN concerts c ON c.id = f.concert_id
        WHERE f.user_id = ?
        ORDER BY f.id DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$res = $stmt->get_result();

$data = [];
while ($row = $res->fetch_assoc()) $data[] = $row;
echo json_encode($data);
