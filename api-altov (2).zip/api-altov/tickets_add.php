<?php
require_once "db.php";
header("Content-Type: application/json");

$user_id = intval($_POST["user_id"] ?? 0);
$concert_id = intval($_POST["concert_id"] ?? 0);
$qty = intval($_POST["qty"] ?? 0);

if ($user_id <= 0 || $concert_id <= 0 || $qty <= 0) {
  echo json_encode(["success"=>false, "message"=>"Data tidak valid"]);
  exit;
}

$stmt = $conn->prepare("SELECT price FROM concerts WHERE id=? LIMIT 1");
$stmt->bind_param("i", $concert_id);
$stmt->execute();
$res = $stmt->get_result();

if ($res->num_rows === 0) {
  echo json_encode(["success"=>false, "message"=>"Concert tidak ditemukan"]);
  exit;
}

$row = $res->fetch_assoc();
$total = intval($row["price"]) * $qty;

$stmt2 = $conn->prepare("INSERT INTO tickets (user_id, concert_id, qty, total_price, status) VALUES (?, ?, ?, ?, 'Booked')");
$stmt2->bind_param("iiii", $user_id, $concert_id, $qty, $total);
$stmt2->execute();

if ($stmt2->affected_rows > 0) {
  echo json_encode(["success"=>true, "message"=>"Booking berhasil", "total"=>$total]);
} else {
  echo json_encode(["success"=>false, "message"=>"Booking gagal"]);
}
