<?php
require_once "db.php";
header("Content-Type: application/json");

$username = trim($_POST["username"] ?? "");
$password = $_POST["password"] ?? "";

if ($username === "" || $password === "") {
  echo json_encode(["success"=>false, "message"=>"Username & password wajib diisi"]);
  exit;
}

$stmt = $conn->prepare(
  "SELECT id, username, full_name, password, role 
   FROM users 
   WHERE username=? 
   LIMIT 1"
);
$stmt->bind_param("s", $username);
$stmt->execute();
$res = $stmt->get_result();

if ($res->num_rows === 0) {
  echo json_encode(["success"=>false, "message"=>"User tidak ditemukan"]);
  exit;
}

$row = $res->fetch_assoc();

if ($row["password"] !== $password) {
  echo json_encode(["success"=>false, "message"=>"Password salah"]);
  exit;
}

echo json_encode([
  "success" => true,
  "message" => "Login berhasil",
  "user" => [
    "id"        => $row["id"],
    "username"  => $row["username"],
    "full_name" => $row["full_name"],
    "role"      => $row["role"]
  ]
]);
?>
