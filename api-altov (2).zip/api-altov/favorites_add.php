<?php
require_once "db.php";
header("Content-Type: application/json");

$user_id = intval($_POST["user_id"] ?? 0);
$concert_id = intval($_POST["concert_id"] ?? 0);

if ($user_id <= 0 || $concert_id <= 0) {
  echo json_encode(["success"=>false, "message"=>"Data tidak valid"]);
  exit;
}

$stmt = $conn->prepare("INSERT IGNORE INTO favorites (user_id, concert_id) VALUES (?, ?)");
$stmt->bind_param("ii", $user_id, $concert_id);
$stmt->execute();

if ($stmt->affected_rows > 0) {
  echo json_encode(["success" => true, "message" => "Berhasil ditambahkan ke favorit"]);
} else {
  echo json_encode(["success" => true, "message" => "Sudah ada di favorit"]);
}
?>
