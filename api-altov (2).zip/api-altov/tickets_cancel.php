<?php
require_once "db.php";
header("Content-Type: application/json");

$user_id = intval($_POST["user_id"] ?? 0);
$ticket_id = intval($_POST["ticket_id"] ?? 0);

if ($user_id <= 0 || $ticket_id <= 0) {
  echo json_encode(["success"=>false, "message"=>"Data tidak valid"]);
  exit;
}

// hanya boleh cancel tiket milik user tersebut
$stmt = $conn->prepare("UPDATE tickets SET status='Canceled' WHERE id=? AND user_id=? AND status='Booked' LIMIT 1");
$stmt->bind_param("ii", $ticket_id, $user_id);
$stmt->execute();

if ($stmt->affected_rows > 0) {
  echo json_encode(["success"=>true, "message"=>"Tiket dibatalkan"]);
} else {
  echo json_encode(["success"=>false, "message"=>"Gagal membatalkan (mungkin sudah cancel / bukan milik user)"]);
}
?>