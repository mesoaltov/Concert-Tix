<?php
require_once "db.php";
header("Content-Type: application/json");

$user_id = intval($_POST["user_id"] ?? 0);
$concert_id = intval($_POST["concert_id"] ?? 0);

if ($user_id <= 0 || $concert_id <= 0) {
  echo json_encode(["success"=>false, "message"=>"Data tidak valid"]);
  exit;
}

$stmt = $conn->prepare("DELETE FROM favorites WHERE user_id=? AND concert_id=? LIMIT 1");
$stmt->bind_param("ii", $user_id, $concert_id);
$stmt->execute();

echo json_encode(["success"=>true, "message"=>"Favorit dihapus"]);
?>