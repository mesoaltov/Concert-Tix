<?php
require_once "db.php";
header("Content-Type: application/json");

$admin_id = intval($_POST["admin_id"] ?? 0);
$id = intval($_POST["id"] ?? 0);
if ($admin_id<=0 || $id<=0) { echo json_encode(["success"=>false,"message"=>"Invalid"]); exit; }

$chk = $conn->prepare("SELECT role FROM users WHERE id=? LIMIT 1");
$chk->bind_param("i", $admin_id);
$chk->execute();
$r = $chk->get_result()->fetch_assoc();
if (!$r || $r["role"] !== "admin") { echo json_encode(["success"=>false,"message"=>"Forbidden"]); exit; }

$title = trim($_POST["title"] ?? "");
$artist = trim($_POST["artist"] ?? "");
$date = trim($_POST["date"] ?? "");
$time = trim($_POST["time"] ?? "");
$city = trim($_POST["city"] ?? "");
$venue = trim($_POST["venue"] ?? "");
$price = intval($_POST["price"] ?? 0);
$category = trim($_POST["category"] ?? "");
$poster_url = trim($_POST["poster_url"] ?? "");

$stmt = $conn->prepare("UPDATE concerts SET title=?, artist=?, date=?, time=?, city=?, venue=?, price=?, category=?, poster_url=? WHERE id=? LIMIT 1");
$stmt->bind_param("ssssssissi", $title,$artist,$date,$time,$city,$venue,$price,$category,$poster_url,$id);
$stmt->execute();

echo json_encode([
  "success" => $stmt->affected_rows >= 0,
  "message" => "Concert diupdate"
]);
