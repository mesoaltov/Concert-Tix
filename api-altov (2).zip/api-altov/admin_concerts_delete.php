<?php
require_once "db.php";
header("Content-Type: application/json");

$admin_id = intval($_POST["admin_id"] ?? 0);
$id = intval($_POST["id"] ?? 0);
if ($admin_id<=0 || $id<=0) { echo json_encode(["success"=>false,"message"=>"Invalid"]); exit; }

$chk = $conn->prepare("SELECT role FROM users WHERE id=? LIMIT 1");
$chk->bind_param("i", $admin_id);
$chk->execute();
$r = $chk->get_result()->fetch_assoc();
if (!$r || $r["role"] !== "admin") { echo json_encode(["success"=>false,"message"=>"Forbidden"]); exit; }

// optional: hapus data relasi
$stmtF = $conn->prepare("DELETE FROM favorites WHERE concert_id=?");
$stmtF->bind_param("i", $id);
$stmtF->execute();

$stmtT = $conn->prepare("DELETE FROM tickets WHERE concert_id=?");
$stmtT->bind_param("i", $id);
$stmtT->execute();

$stmt = $conn->prepare("DELETE FROM concerts WHERE id=? LIMIT 1");
$stmt->bind_param("i", $id);
$stmt->execute();

echo json_encode([
  "success" => $stmt->affected_rows > 0,
  "message" => $stmt->affected_rows > 0 ? "Concert dihapus" : "Gagal menghapus"
]);
