<?php
require_once "db.php";
header("Content-Type: application/json");

$search = trim($_GET["search"] ?? "");

if ($search !== "") {
  $like = "%".$search."%";
  $stmt = $conn->prepare("SELECT * FROM concerts WHERE title LIKE ? OR artist LIKE ? ORDER BY id DESC");
  $stmt->bind_param("ss", $like, $like);
  $stmt->execute();
  $res = $stmt->get_result();
} else {
  $res = $conn->query("SELECT * FROM concerts ORDER BY id DESC");
}

$data = [];
while ($row = $res->fetch_assoc()) $data[] = $row;

echo json_encode($data);
