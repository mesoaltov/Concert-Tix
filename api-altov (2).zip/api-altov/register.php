<?php
require_once "db.php";
header("Content-Type: application/json");

$full_name = trim($_POST["full_name"] ?? "");
$username  = trim($_POST["username"] ?? "");
$password  = $_POST["password"] ?? "";

if ($full_name === "" || $username === "" || $password === "") {
  echo json_encode(["success"=>false, "message"=>"Nama lengkap, username & password wajib diisi"]);
  exit;
}

$check = $conn->prepare("SELECT id FROM users WHERE username=? LIMIT 1");
$check->bind_param("s", $username);
$check->execute();
$checkRes = $check->get_result();

if ($checkRes->num_rows > 0) {
  echo json_encode(["success"=>false, "message"=>"Username sudah dipakai"]);
  exit;
}

// default role user + simpan full_name
$stmt = $conn->prepare("INSERT INTO users (username, full_name, password, role) VALUES (?, ?, ?, 'user')");
$stmt->bind_param("sss", $username, $full_name, $password);
$stmt->execute();

if ($stmt->affected_rows > 0) {
  $newId = $conn->insert_id;
  echo json_encode([
    "success"=>true,
    "message"=>"Register berhasil"
  ]);
} else {
  echo json_encode(["success"=>false, "message"=>"Register gagal"]);
}
?>
