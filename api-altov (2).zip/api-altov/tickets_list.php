<?php
require_once "db.php";
header("Content-Type: application/json");

$user_id = intval($_GET["user_id"] ?? 0);
if ($user_id <= 0) { echo json_encode([]); exit; }

$sql = "SELECT 
          t.id,
          t.qty,
          t.total_price AS totalPrice,
          t.status,
          t.created_at AS createdAt,
          c.id AS concertId,
          c.title AS concertTitle,
          c.artist,
          c.date,
          c.city
        FROM tickets t
        JOIN concerts c ON c.id = t.concert_id
        WHERE t.user_id = ?
        ORDER BY t.id DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$res = $stmt->get_result();

$data = [];
while ($row = $res->fetch_assoc()) $data[] = $row;
echo json_encode($data);
